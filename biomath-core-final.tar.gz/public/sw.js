self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

// bust 1761541711

// bust 1761542012

// bust 1761543607
