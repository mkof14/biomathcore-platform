import EnhancedUserManagement from './EnhancedUserManagement';

export default function UserManagementSection() {
  return <EnhancedUserManagement />;
}
