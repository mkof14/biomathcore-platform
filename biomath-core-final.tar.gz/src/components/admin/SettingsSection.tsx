import EnhancedSettingsSection from './EnhancedSettingsSection';

export default function SettingsSection() {
  return <EnhancedSettingsSection />;
}
