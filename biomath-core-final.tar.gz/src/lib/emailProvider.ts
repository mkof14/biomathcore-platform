import { Resend } from 'resend';

const resend = new Resend(import.meta.env.VITE_RESEND_API_KEY);

export const sendEmail = async (to: string, subject: string, html: string) => {
  try {
    const { data, error } = await resend.emails.send({
      from: 'BioMath <noreply@biomath.ai>',
      to: [to],
      subject: subject,
      html: html,
    });

    if (error) {
      console.error({ error });
      return { success: false, error };
    }
    console.log({ data });
    return { success: true, data };
  } catch (error) {
    console.error({ error });
    return { success: false, error };
  }
};

export const renderTemplate = (template: string, data: Record<string, string>): string => {
  let renderedTemplate = template;
  for (const key in data) {
    const regex = new RegExp(`{{${key}}}`, 'g');
    renderedTemplate = renderedTemplate.replace(regex, data[key]);
  }
  return renderedTemplate;
};
